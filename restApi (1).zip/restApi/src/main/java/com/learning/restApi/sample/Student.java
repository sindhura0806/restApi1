package com.learning.restApi.sample;

import lombok.*;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {private String name;
    private int rollNumber;

//    public Student( String name, int rollNumber) {
//        this.name = name;
//        this.rollNumber = rollNumber;
//    }

}
