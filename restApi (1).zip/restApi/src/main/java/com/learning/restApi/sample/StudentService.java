package com.learning.restApi.sample;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentService {
    public List<Student> getAll() {

        List<Student> studentList = new ArrayList();
        Student monish = new Student("Monish",  6);
        Student arun= new Student("Arun", 23);
        Student raghu= new Student("Raghu", 11);

        studentList.add(monish );
        studentList.add(arun);
        studentList.add(raghu);

        return studentList;
    }

}
